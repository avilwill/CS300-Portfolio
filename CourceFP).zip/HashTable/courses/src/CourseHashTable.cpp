
//============================================================================
// Name        : CourseHashTable.cpp
// Author      : Danielle Williams
// Version     : 1.0
// Copyright   : Copyright © 2023 SNHU COCE
//============================================================================
#include <algorithm>
#include <climits>
#include <iostream>
#include <string> // atoi
#include <time.h>
#include "CSVparser.hpp"

using namespace std;

const unsigned int DEFAULT_SIZE = 179;

double strToDouble(string str, char ch);

// Define a structure to hold course information
struct Course {
    string courseId;
    string title;
    string prereq1;
    string prereq2;

    Course() {
        courseId = "";
        title = "";
        prereq1 = "";
        prereq2 = "";

    }
};

class HashTable {
private:
    struct Node {
        Course course;
        unsigned int key;
        Node* next;
        Node() {
            key = UINT_MAX;
            next = nullptr;
        }
        Node(Course aCourse) : Node() {
            course = aCourse;
        }
        Node(Course aCourse, unsigned int aKey) : Node(aCourse) {
            key = aKey;
        }
    };

    vector<Node> nodes;
    unsigned int tableSize = DEFAULT_SIZE;
    unsigned int hash(int key);

public:
    HashTable();
    HashTable(unsigned int size);
    virtual ~HashTable();
    void Insert(Course course);
    void PrintAll();
    void Remove(string courseId);
    Course Search(string courseId);
    size_t Size();
};

HashTable::HashTable() {
    nodes.resize(tableSize);
}

HashTable::HashTable(unsigned int size) {
    tableSize = size;
    nodes.resize(tableSize);
}

HashTable::~HashTable() {
    for (unsigned int i = 0; i < nodes.size(); ++i) {
        Node* current = nodes[i].next;
        while (current != nullptr) {
            Node* temp = current;
            current = current->next;
            delete temp;
        }
    }
    nodes.erase(nodes.begin(), nodes.end());
}

unsigned int HashTable::hash(int key) {
    return key % tableSize;
}

void HashTable::Insert(Course course) {
    unsigned int key = hash(atoi(course.courseId.c_str()));
    Node* node = &nodes[key];
    if (node->key == UINT_MAX) {
        node->key = key;
        node->course = course;
        node->next = nullptr;
    } else {
        while (node->next != nullptr) {
            node = node->next;
        }
        node->next = new Node(course, key);
    }
}

void HashTable::PrintAll() {
    for (unsigned int i = 0; i < nodes.size(); ++i) {
        Node* node = &nodes[i];
        if (node->key != UINT_MAX) {
            cout << node->key << ": " << node->course.courseId << " | "
                 << node->course.title << " | " << node->course.prereq1 << endl;
            node = node->next;
            while (node != nullptr) {
                cout << node->key << ": " << node->course.courseId << " | "
                     << node->course.title << " | " << node->course.prereq1 << endl;
                node = node->next;
            }
        }
    }
}

void HashTable::Remove(string courseId) {
    unsigned int key = hash(atoi(courseId.c_str()));
    Node* node = &nodes[key];
    Node* prev = nullptr;
    while (node != nullptr) {
        if (node->course.courseId == courseId) {
            if (prev == nullptr) {
                if (node->next != nullptr) {
                    Node* temp = node->next;
                    *node = *temp;
                    delete temp;
                } else {
                    node->key = UINT_MAX;
                    node->course = Course();
                }
            } else {
                prev->next = node->next;
                delete node;
            }
            return;
        }
        prev = node;
        node = node->next;
    }
}

Course HashTable::Search(string courseId) {
    Course course;
    unsigned int key = hash(atoi(courseId.c_str()));
    Node* node = &nodes[key];
    while (node != nullptr) {
        if (node->course.courseId == courseId) {
            return node->course;
        }
        node = node->next;
    }
    return course;
}

void displayCourse(Course course) {
    cout << course.courseId << ": " << course.title << " | " << course.prereq1 << endl;
    return;
}

void loadCourses(string csvPath, HashTable* hashTable) {
    cout << "Loading CSV file " << csvPath << endl;
    csv::Parser file = csv::Parser(csvPath);
    vector<string> header = file.getHeader();
    for (auto const& c : header) {
        cout << c << " | ";
    }
    cout << "" << endl;

    try {
        for (unsigned int i = 0; i < file.rowCount(); i++) {
            Course course;
            course.courseId = file[i][0];
            course.title = file[i][1];
            course.prereq1 = file[i][2];
            course.prereq2 = file[i][3];

            hashTable->Insert(course);
        }
    } catch (csv::Error& e) {
        cerr << e.what() << endl;
    }
}

double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

int main(int argc, char* argv[]) {
    string csvPath, courseKey;
    switch (argc) {
        case 2:
            csvPath = argv[1];
            courseKey = "CSCI100";
            break;
        case 3:
            csvPath = argv[1];
            courseKey = argv[2];
            break;
        default:
            csvPath = "cleaned_courses.csv";
            courseKey = "CSCI100";
    }

    clock_t ticks;
    HashTable* courseTable;
    Course course;
    courseTable = new HashTable();

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Courses" << endl;
        cout << "  2. Display All Courses" << endl;
        cout << "  3. Find Course" << endl;
        cout << "  4. Remove Course" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            ticks = clock();
            loadCourses(csvPath, courseTable);
            ticks = clock() - ticks;
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;
        case 2:
            courseTable->PrintAll();
            break;
        case 3:{
            string courseId;
            cout << "What course do you want to know about? ";
            cin >> courseId;
        
            transform(courseId.begin(), courseId.end(), courseId.begin(), ::toupper);
        
            course = courseTable->Search(courseId);
        
            if (!course.courseId.empty()) {
                cout << course.courseId << ", " << course.title << endl;
                cout << "Prerequisites: ";
                bool hasPrereq = false;
                if (!course.prereq1.empty()) {
                    cout << course.prereq1;
                    hasPrereq = true;
                }
                if (!course.prereq2.empty()) {
                    if (hasPrereq) {cout << ", ";
                    cout << course.prereq2;
                    }
                }
                if (!hasPrereq) cout << "None";
                cout << endl;
            } else {
                cout << "Course ID " << courseId << " not found." << endl;
            }
            break;
        }
        case 4:
            courseTable->Remove(courseKey);
            break;
        }
    }

    cout << "Good bye." << endl;
    return 0;
}
